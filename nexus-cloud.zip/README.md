# NEXUS CLOUD — *Your data. Your universe.*
**Frontend prototype.** No SSD, phone, or backend is connected. All "storage" is browser localStorage + IndexedDB; uploaded files never leave your browser and are NOT on any SSD. Demo file metadata is simulated.

## Run
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # type-check + production build into dist/
```
## Deploy to GitHub Pages (static frontend only)
```bash
git init && git add . && git commit -m "NEXUS CLOUD prototype"
git branch -M main && git remote add origin https://github.com/<you>/<repo>.git && git push -u origin main
npm run build
npx gh-pages -d dist      # then Settings → Pages → branch gh-pages
```
`base: './'` and `HashRouter` make routing work under any repo path. Pages cannot serve your SSD or run a storage server.

## Architecture
`src/storage.ts` defines `StorageProvider` (list, rename, move, trash, restore, upload, search, status…) and `MockStorageProvider`. UI only uses the exported `storage`. To go real, write `HttpStorageProvider` calling a REST API and swap it in one line.

## Backend integration (future, not built)
A host (e.g. Android phone running a small server, with the SSD attached) would expose a **private** API: authentication (short-lived tokens kept in memory/HttpOnly cookies, never in git), HTTPS (e.g. via a VPN/tunnel such as WireGuard/Tailscale rather than open ports), path sanitising against `..` traversal, per-user authorization, upload size limits and type allow-lists, and CORS restricted to your frontend origin. Never commit secrets; keep backend config in a separate private repo.

## Manual test checklist
Landing 3D follows mouse · CTA opens /app · open folders & breadcrumbs · search · sort · grid/list · upload & drag-drop · preview image/text · rename/star/move/trash/restore/delete forever · refresh persists · theme persists · Reset Demo Data.

## Not yet included (planned)
Right-side details panel, collapsible sidebar/tooltips, context menu, skeletons, IndexedDB-backed activity charts, Tailwind/Framer Motion/Lucide.

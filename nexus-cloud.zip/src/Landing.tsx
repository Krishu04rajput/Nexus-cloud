import {lazy,Suspense} from 'react';import {Link} from 'react-router-dom';
const Core=lazy(()=>import('./Core'));
const rows:[string,string,boolean][]=[['Browser interface','Implemented',true],['Demo service','Implemented',true],['Storage API','Not connected',false],['Local host','Not connected',false],['Physical SSD','Not connected',false]];
export default function Landing(){return <div className="landing">
 <nav className="nav"><b className="logo">◇ NEXUS CLOUD</b><span className="links"><a href="#features">Features</a><a href="#arch">Architecture</a><Link className="btn" to="/app">Enter Cloud</Link></span></nav>
 <header className="hero"><div className="canvas"><Suspense fallback={<div className="fallback"/>}><Core/></Suspense></div>
  <div className="heroText"><span className="chip"><i className="dot off"/>PROTOTYPE MODE · STORAGE OFFLINE</span>
   <h1>Your data.<br/>Your universe.</h1><p>A personal storage environment designed around your files, your hardware, and your control.</p>
   <div className="row"><Link className="btn primary" to="/app">Enter Your Cloud</Link><a className="btn" href="#features">Explore the System</a></div></div></header>
 <section className="pad status"><h3>Storage status</h3><ul><li>Storage device: Not connected</li><li>Backend: Not configured</li><li>Connection: Offline</li><li>Environment: Prototype</li><li>Data source: Demo dataset</li></ul></section>
 <section id="features" className="pad grid4">{[['Your Files, One Universe','Browse files and folders through an elegant interface.'],['Local-First by Design','Architecture prepared for storage on hardware you control.'],['A Workspace Built for Speed','Search, sort, preview and organize efficiently.'],['Ready for Real Hardware','UI is separated from the storage service via a StorageProvider interface.']].map(([t,d])=><article key={t} className="card"><h3>{t}</h3><p>{d}</p></article>)}</section>
 <section id="arch" className="pad"><h2>Architecture</h2><div className="arch">{rows.map(([n,s,ok],i)=><div key={n} className="node"><b>{n}</b><span className={ok?'ok':'no'}>{s}</span>{i<4&&<em>→</em>}</div>)}</div><p className="muted">Browser → Storage API → Local Storage Host → SSD. Only the first two boxes exist today.</p></section>
 <section className="pad cta"><h2>Your cloud starts here.</h2><p>Explore your personal storage environment.</p><Link className="btn primary" to="/app">Open NEXUS CLOUD</Link></section></div>}

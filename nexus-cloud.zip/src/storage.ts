// Storage abstraction. UI talks ONLY to `storage` (below). Replace MockStorageProvider with an
// HttpStorageProvider later; no component changes needed.
export interface Item{id:string;name:string;kind:'folder'|'file';parent:string|null;size:number;modified:number;starred:boolean;trashed:boolean;simulated:boolean;mime?:string}
export interface StorageProvider{
 status():Promise<{connected:boolean;backend:string;note:string}>;
 all():Promise<Item[]>;
 list(parent:string|null):Promise<Item[]>;
 search(q:string):Promise<Item[]>;
 createFolder(name:string,parent:string|null):Promise<Item>;
 rename(id:string,name:string):Promise<void>;
 move(id:string,parent:string|null):Promise<void>;
 setStar(id:string,v:boolean):Promise<void>;
 trash(id:string):Promise<void>;
 restore(id:string):Promise<void>;
 remove(id:string):Promise<void>;
 upload(f:File,parent:string|null):Promise<Item>;
 getBlob(id:string):Promise<Blob|null>;
 reset():Promise<void>;
}
const KEY='nexus.items.v1',DB='nexus-blobs';
const idb=():Promise<IDBDatabase>=>new Promise((res,rej)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore('b');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
const blobOp=async<T,>(m:IDBTransactionMode,f:(s:IDBObjectStore)=>IDBRequest<T>):Promise<T>=>{const d=await idb();return new Promise((res,rej)=>{const r=f(d.transaction('b',m).objectStore('b'));r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})};
const uid=()=>Math.random().toString(36).slice(2,10);
const D=(d:number)=>Date.now()-d*864e5;
const seed=():Item[]=>{const f=(id:string,name:string,parent:string|null,d:number):Item=>({id,name,kind:'folder',parent,size:0,modified:D(d),starred:false,trashed:false,simulated:true});
 const t=(id:string,name:string,parent:string|null,size:number,d:number,mime:string):Item=>({id,name,kind:'file',parent,size,modified:D(d),starred:false,trashed:false,simulated:true,mime});
 return [f('personal','Personal',null,30),f('documents','Documents',null,12),f('projects','Projects',null,3),f('photos','Photos',null,40),f('videos','Videos',null,25),f('music','Music',null,60),f('ai','AI Development',null,5),f('backups','Backups',null,90),
 t('1','README.md',null,2048,1,'text/markdown'),t('2','Project-Plan.pdf','documents',1843200,6,'application/pdf'),t('3','System-Architecture.png','projects',912000,2,'image/png'),t('4','Vacation.jpg','photos',4200000,35,'image/jpeg'),
 t('5','Sample-Video.mp4','videos',58000000,20,'video/mp4'),t('6','Notes.txt','documents',1200,8,'text/plain'),t('7','app.tsx','projects',5400,1,'text/plain'),t('8','dataset.json','ai',88000,4,'application/json'),t('9','Presentation.pptx','documents',7300000,15,'application/vnd.ms-powerpoint')]};
export class MockStorageProvider implements StorageProvider{
 private load():Item[]{try{const s=localStorage.getItem(KEY);if(s)return JSON.parse(s)}catch{}return seed()}
 private save(i:Item[]){try{localStorage.setItem(KEY,JSON.stringify(i))}catch{throw new Error('Browser storage quota exceeded')}}
 private async mut(fn:(i:Item[])=>void){const i=this.load();fn(i);this.save(i)}
 async status(){return{connected:false,backend:'MockStorageProvider (browser only)',note:'No SSD, phone or backend is connected. Data lives in this browser.'}}
 async all(){return this.load()}
 async list(p:string|null){return this.load().filter(i=>i.parent===p&&!i.trashed)}
 async search(q:string){const s=q.toLowerCase();return this.load().filter(i=>!i.trashed&&(i.name.toLowerCase().includes(s)||(i.mime||'').toLowerCase().includes(s)))}
 async createFolder(name:string,parent:string|null){const it:Item={id:uid(),name,kind:'folder',parent,size:0,modified:Date.now(),starred:false,trashed:false,simulated:false};await this.mut(i=>{i.push(it)});return it}
 async rename(id:string,name:string){await this.mut(i=>{const x=i.find(y=>y.id===id);if(x){x.name=name;x.modified=Date.now()}})}
 async move(id:string,parent:string|null){if(id===parent)return;await this.mut(i=>{const x=i.find(y=>y.id===id);if(x)x.parent=parent})}
 async setStar(id:string,v:boolean){await this.mut(i=>{const x=i.find(y=>y.id===id);if(x)x.starred=v})}
 async trash(id:string){await this.mut(i=>{const x=i.find(y=>y.id===id);if(x)x.trashed=true})}
 async restore(id:string){await this.mut(i=>{const x=i.find(y=>y.id===id);if(x)x.trashed=false})}
 async remove(id:string){await this.mut(i=>{const ids=new Set([id]);let n=0;while(ids.size!==n){n=ids.size;i.forEach(y=>{if(y.parent&&ids.has(y.parent))ids.add(y.id)})}
  for(let k=i.length-1;k>=0;k--)if(ids.has(i[k].id)){blobOp('readwrite',s=>s.delete(i[k].id)).catch(()=>{});i.splice(k,1)}})}
 async upload(f:File,parent:string|null){const it:Item={id:uid(),name:f.name,kind:'file',parent,size:f.size,modified:f.lastModified||Date.now(),starred:false,trashed:false,simulated:false,mime:f.type||'application/octet-stream'};
  try{await blobOp('readwrite',s=>s.put(f,it.id))}catch{throw new Error('Could not store "'+f.name+'" in browser storage (quota?)')}
  await this.mut(i=>{i.push(it)});return it}
 async getBlob(id:string){try{return(await blobOp('readonly',s=>s.get(id)))||null}catch{return null}}
 async reset(){localStorage.removeItem(KEY);const d=await idb();await new Promise<void>(r=>{const q=d.transaction('b','readwrite').objectStore('b').clear();q.onsuccess=()=>r();q.onerror=()=>r()})}
}
export const storage:StorageProvider=new MockStorageProvider();
export const fmtSize=(n:number)=>n<1?'—':n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':n<1073741824?(n/1048576).toFixed(1)+' MB':(n/1073741824).toFixed(2)+' GB';

import {StrictMode,lazy,Suspense} from 'react';import {createRoot} from 'react-dom/client';import {HashRouter,Routes,Route} from 'react-router-dom';import './styles.css';
import Landing from './Landing';
const Browse=lazy(()=>import('./Browse'));
createRoot(document.getElementById('root')!).render(<StrictMode><HashRouter><Suspense fallback={<div className="pad">Loading…</div>}><Routes><Route path="/" element={<Landing/>}/><Route path="/app" element={<Browse/>}/><Route path="*" element={<Landing/>}/></Routes></Suspense></HashRouter></StrictMode>);

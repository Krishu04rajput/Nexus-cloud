import {useRef,useState} from 'react';import {Canvas,useFrame} from '@react-three/fiber';import * as THREE from 'three';
const reduce=typeof matchMedia!=='undefined'&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function Scene(){
 const g=useRef<THREE.Group>(null!),core=useRef<THREE.Mesh>(null!),rings=useRef<THREE.Group>(null!);
 const [hov,setHov]=useState(false);const pulse=useRef(0);
 const pts=useRef(new Float32Array(Array.from({length:240},(_,i)=>{const r=2.2+Math.random()*1.6,a=Math.random()*6.28,b=Math.random()*3.14;return i%3===0?r*Math.sin(b)*Math.cos(a):i%3===1?r*Math.cos(b):r*Math.sin(b)*Math.sin(a)}))).current;
 useFrame((s,dt)=>{const m=reduce||'ontouchstart' in window?{x:Math.sin(s.clock.elapsedTime*.3)*.3,y:0}:s.pointer;
  g.current.rotation.y+=(m.x*.5-g.current.rotation.y)*Math.min(1,dt*3);g.current.rotation.x+=(-m.y*.3-g.current.rotation.x)*Math.min(1,dt*3);
  if(!reduce){core.current.rotation.y+=dt*.3;rings.current.rotation.z+=dt*.1;}
  pulse.current=Math.max(0,pulse.current-dt*2);const k=1+(hov?.06:0)+pulse.current*.25;core.current.scale.setScalar(k);
  (core.current.material as THREE.MeshStandardMaterial).emissiveIntensity=(hov?1.2:.6)+pulse.current*2});
 return <group ref={g}>
  <mesh ref={core} onPointerOver={()=>setHov(true)} onPointerOut={()=>setHov(false)} onClick={()=>{pulse.current=1}}><icosahedronGeometry args={[1,1]}/><meshStandardMaterial color="#65E7FF" emissive="#65E7FF" emissiveIntensity={.6} wireframe={false} flatShading metalness={.6} roughness={.25}/></mesh>
  <group ref={rings}>{[[0,0],[1.1,.4],[.5,1.2]].map(([x,y],i)=><mesh key={i} rotation={[x,y,0]}><torusGeometry args={[1.8+i*.5,.008,8,128]}/><meshBasicMaterial color={i%2?'#8B7CFF':'#65E7FF'} transparent opacity={.6}/></mesh>)}</group>
  <points><bufferGeometry><bufferAttribute attach="attributes-position" array={pts} count={pts.length/3} itemSize={3}/></bufferGeometry><pointsMaterial size={.03} color="#8B7CFF" transparent opacity={.8}/></points>
  <pointLight position={[3,2,3]} color="#65E7FF" intensity={30}/><pointLight position={[-3,-2,2]} color="#8B7CFF" intensity={30}/><ambientLight intensity={.2}/>
 </group>}
export default function Core(){
 const ok=(()=>{try{return!!document.createElement('canvas').getContext('webgl2')||!!document.createElement('canvas').getContext('webgl')}catch{return false}})();
 if(!ok)return <div className="fallback" aria-hidden/>;
 return <Canvas dpr={[1,1.5]} camera={{position:[0,0,6],fov:50}} gl={{antialias:true,powerPreference:'low-power'}} aria-label="Interactive 3D storage core"><Scene/></Canvas>}

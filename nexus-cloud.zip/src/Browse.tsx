import {useCallback,useEffect,useMemo,useState} from 'react';import {Link} from 'react-router-dom';import {storage,fmtSize,Item} from './storage';
type View='files'|'starred'|'trash'|'storage'|'settings';type Sort='name'|'size'|'modified'|'type';
const pref=<T,>(k:string,d:T):T=>{try{const v=localStorage.getItem('nexus.'+k);return v?JSON.parse(v):d}catch{return d}};
const ext=(n:string)=>(n.split('.').pop()||'').toLowerCase();
export default function Browse(){
 const [items,setItems]=useState<Item[]>([]);const [view,setView]=useState<View>('files');const [cwd,setCwd]=useState<string|null>(null);
 const [q,setQ]=useState('');const [sort,setSort]=useState<Sort>('name');const [grid,setGrid]=useState<boolean>(pref('grid',true));const [theme,setTheme]=useState<string>(pref('theme','dark'));
 const [sel,setSel]=useState<Set<string>>(new Set());const [toast,setToast]=useState('');const [prev,setPrev]=useState<{item:Item;url?:string;text?:string}|null>(null);const [drag,setDrag]=useState(false);
 const say=(m:string)=>{setToast(m);setTimeout(()=>setToast(''),2800)};
 const refresh=useCallback(async()=>setItems(await storage.all()),[]);
 useEffect(()=>{refresh()},[refresh]);
 useEffect(()=>{localStorage.setItem('nexus.grid',JSON.stringify(grid));localStorage.setItem('nexus.theme',JSON.stringify(theme));document.documentElement.dataset.theme=theme},[grid,theme]);
 const run=async(f:()=>Promise<unknown>,ok?:string)=>{try{await f();await refresh();if(ok)say(ok)}catch(e){say((e as Error).message)}};
 const shown=useMemo(()=>{let l=items.filter(i=>view==='trash'?i.trashed:!i.trashed);
  if(q)l=l.filter(i=>(i.name+' '+(i.mime||'')).toLowerCase().includes(q.toLowerCase()));
  else if(view==='starred')l=l.filter(i=>i.starred);else if(view==='files')l=l.filter(i=>i.parent===cwd);
  const c=(a:Item,b:Item)=>sort==='size'?b.size-a.size:sort==='modified'?b.modified-a.modified:sort==='type'?ext(a.name).localeCompare(ext(b.name)):a.name.localeCompare(b.name);
  return [...l].sort((a,b)=>(a.kind===b.kind?c(a,b):a.kind==='folder'?-1:1))},[items,view,cwd,q,sort]);
 const crumbs=useMemo(()=>{const p:Item[]=[];let c=cwd;while(c){const f=items.find(i=>i.id===c);if(!f)break;p.unshift(f);c=f.parent}return p},[items,cwd]);
 const open=async(i:Item)=>{if(i.trashed)return;if(i.kind==='folder'){setView('files');setCwd(i.id);setQ('');setSel(new Set());return}
  const b=await storage.getBlob(i.id);const m=i.mime||'';
  if(b&&m.startsWith('image/')||b&&m.startsWith('video/')||b&&m.startsWith('audio/')||b&&m==='application/pdf')setPrev({item:i,url:URL.createObjectURL(b)});
  else if(b&&(m.startsWith('text/')||m==='application/json')){let t=await b.text();if(m==='application/json')try{t=JSON.stringify(JSON.parse(t),null,2)}catch{}setPrev({item:i,text:t})}
  else setPrev({item:i})};
 const closePrev=()=>{if(prev?.url)URL.revokeObjectURL(prev.url);setPrev(null)};
 const upload=(fs:FileList|File[])=>run(async()=>{for(const f of Array.from(fs))await storage.upload(f,cwd)},'Uploaded to browser storage (not an SSD)');
 const selected=items.filter(i=>sel.has(i.id));
 const act=(fn:(i:Item)=>Promise<unknown>,msg:string)=>run(async()=>{for(const i of selected)await fn(i);setSel(new Set())},msg);
 useEffect(()=>{const h=(e:KeyboardEvent)=>{if(e.key==='Escape'){closePrev();setSel(new Set())}
  if(e.key==='/'&&document.activeElement?.tagName!=='INPUT'){e.preventDefault();document.getElementById('search')?.focus()}
  if(e.key==='Delete'&&selected.length&&view!=='trash')act(i=>storage.trash(i.id),'Moved to Trash')};
  window.addEventListener('keydown',h);return()=>window.removeEventListener('keydown',h)});
 const nav:[View,string][]=[['files','All Files'],['starred','Starred'],['trash','Trash'],['storage','Storage'],['settings','Settings']];
 const real=items.filter(i=>!i.simulated&&i.kind==='file');
 return <div className="shell" onDragOver={e=>{e.preventDefault();setDrag(true)}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);if(e.dataTransfer.files.length)upload(e.dataTransfer.files)}}>
  <aside className="side"><Link to="/" className="logo">◇ NEXUS</Link>{nav.map(([v,l])=><button key={v} className={view===v?'on':''} onClick={()=>{setView(v);setCwd(null);setQ('')}}>{l}</button>)}
   <h6>LOCATIONS (virtual)</h6>{items.filter(i=>i.kind==='folder'&&i.parent===null&&!i.trashed).map(f=><button key={f.id} onClick={()=>{setView('files');setCwd(f.id)}}>{f.name}</button>)}</aside>
  <main className="main">
   {(view==='files'||view==='starred'||view==='trash')&&<>
   <div className="bar"><input id="search" aria-label="Search" placeholder="Search all files  ( / )" value={q} onChange={e=>setQ(e.target.value)}/>{q&&<button onClick={()=>setQ('')}>Clear</button>}
    <select aria-label="Sort" value={sort} onChange={e=>setSort(e.target.value as Sort)}><option value="name">Name</option><option value="size">Size</option><option value="modified">Modified</option><option value="type">Type</option></select>
    <button onClick={()=>setGrid(!grid)}>{grid?'List':'Grid'}</button>
    {view==='files'&&<><label className="btn">Upload<input type="file" multiple hidden onChange={e=>e.target.files&&upload(e.target.files)}/></label>
     <button onClick={()=>{const n=prompt('Folder name');if(n?.trim())run(()=>storage.createFolder(n.trim(),cwd),'Folder created')}}>New Folder</button></>}</div>
   <div className="crumbs"><button onClick={()=>setCwd(null)}>Personal Drive</button>{crumbs.map(c=><span key={c.id}> / <button onClick={()=>setCwd(c.id)}>{c.name}</button></span>)}<span className="muted"> · demo metadata is simulated</span></div>
   {selected.length>0&&<div className="bar sel">{selected.length} selected
    {view==='trash'?<><button onClick={()=>act(i=>storage.restore(i.id),'Restored')}>Restore</button><button onClick={()=>confirm('Permanently delete from this demo? (No physical SSD is affected.)')&&act(i=>storage.remove(i.id),'Deleted')}>Delete forever</button></>:<>
    <button onClick={()=>act(i=>storage.setStar(i.id,!i.starred),'Updated star')}>Star</button>
    <button disabled={selected.length!==1} onClick={()=>{const n=prompt('New name',selected[0].name);if(n?.trim())act(i=>storage.rename(i.id,n.trim()),'Renamed')}}>Rename</button>
    <button onClick={()=>{const n=prompt('Move to folder name (blank = root)');const t=n?items.find(i=>i.kind==='folder'&&!i.trashed&&i.name.toLowerCase()===n.toLowerCase()):null;if(n&&!t)say('Folder not found');else act(i=>storage.move(i.id,t?t.id:null),'Moved')}}>Move</button>
    <button onClick={()=>act(i=>storage.trash(i.id),'Moved to Trash')}>Trash</button></>}</div>}
   {shown.length===0?<p className="empty">Nothing here. {view==='files'&&'Upload files or drop them anywhere.'}</p>:
   <div className={grid?'tiles':'list'}>{shown.map(i=><div key={i.id} draggable onDragStart={e=>e.dataTransfer.setData('id',i.id)} onDragOver={e=>i.kind==='folder'&&e.preventDefault()} onDrop={e=>{const id=e.dataTransfer.getData('id');if(id&&i.kind==='folder'){e.stopPropagation();run(()=>storage.move(id,i.id),'Moved')}}}
     tabIndex={0} className={'it'+(sel.has(i.id)?' on':'')} onClick={e=>setSel(s=>{const n=new Set(e.metaKey||e.ctrlKey||e.shiftKey?s:[]);n.has(i.id)&&(e.metaKey||e.ctrlKey||e.shiftKey)?n.delete(i.id):n.add(i.id);return n})} onDoubleClick={()=>open(i)} onKeyDown={e=>e.key==='Enter'&&open(i)}>
     <span className="ico">{i.kind==='folder'?'📁':ext(i.name).toUpperCase().slice(0,4)||'FILE'}</span><b>{i.starred&&'★ '}{q?i.name.split(new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','i')).map((p,k)=>p.toLowerCase()===q.toLowerCase()?<mark key={k}>{p}</mark>:p):i.name}</b>
     <small>{fmtSize(i.size)} · {new Date(i.modified).toLocaleDateString()}{i.simulated?' · demo':' · browser'}</small></div>)}</div>}</>}
   {view==='storage'&&<div className="pad"><h2>Storage (simulated)</h2><p className="warn">Real SSD capacity: unavailable — no storage backend is connected.</p>
    <ul><li>Demo folders: {items.filter(i=>i.simulated&&i.kind==='folder').length}</li><li>Demo files (fake metadata): {items.filter(i=>i.simulated&&i.kind==='file').length}</li><li>Browser-managed uploads: {real.length} files, {fmtSize(real.reduce((a,b)=>a+b.size,0))}</li></ul>
    <button disabled title="Needs a self-hosted storage API">Connect Storage Backend</button><p className="muted">Needs an authenticated HTTPS storage API on a host you control. See README → Backend integration.</p></div>}
   {view==='settings'&&<div className="pad"><h2>Settings</h2><p><label>Theme <select value={theme} onChange={e=>setTheme(e.target.value)}><option value="dark">Dark</option><option value="light">Light</option></select></label></p>
    <p><label>Default view <select value={grid?'grid':'list'} onChange={e=>setGrid(e.target.value==='grid')}><option value="grid">Grid</option><option value="list">List</option></select></label></p>
    <p className="muted">Shortcuts: / search · Enter open · Delete trash · Esc close · double-click open</p>
    <button onClick={()=>confirm('Reset demo data and browser-stored uploads? Nothing on any physical SSD is touched.')&&run(async()=>{await storage.reset();setCwd(null)},'Demo data reset')}>Reset Demo Data</button>
    <p className="warn">NEXUS CLOUD is a frontend prototype. No physical SSD is connected.</p></div>}
  </main>
  {prev&&<div className="modal" role="dialog" aria-modal="true" onClick={closePrev}><div className="box" onClick={e=>e.stopPropagation()}><h3>{prev.item.name} <small>{fmtSize(prev.item.size)}</small></h3>
   {prev.url?(prev.item.mime!.startsWith('image/')?<img src={prev.url} alt={prev.item.name}/>:prev.item.mime!.startsWith('video/')?<video src={prev.url} controls/>:prev.item.mime!.startsWith('audio/')?<audio src={prev.url} controls/>:<iframe src={prev.url} title={prev.item.name}/>):
    prev.text!==undefined?<pre>{prev.text}</pre>:<p className="muted">SAMPLE PREVIEW — this is a simulated demo file with no real content.</p>}
   {prev.url&&<a className="btn" href={prev.url} download={prev.item.name}>Download</a>} <button onClick={closePrev}>Close</button></div></div>}
  {drag&&<div className="drop">Drop to upload to browser storage</div>}{toast&&<div className="toast" role="status">{toast}</div>}</div>}
